put your dump file directly to this folder directly
then run 'convertData.py' python file in python3
data CSV will dumped into same folder as 'dumpData.csv'
